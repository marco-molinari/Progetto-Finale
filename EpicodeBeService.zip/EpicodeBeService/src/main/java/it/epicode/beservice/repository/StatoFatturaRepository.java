package it.epicode.beservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.epicode.beservice.model.StatoFattura;

public interface StatoFatturaRepository extends JpaRepository<StatoFattura, Long>{
	
	StatoFattura findByNome(String nome);

}
