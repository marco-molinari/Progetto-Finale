package it.epicode.beservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpicodeBeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpicodeBeServiceApplication.class, args);
	}

}
