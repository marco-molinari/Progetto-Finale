package it.epicode.beservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.model.Indirizzo;
import it.epicode.beservice.repository.IndirizzoRepository;

@Service
public class IndirizzoService {

	@Autowired
	IndirizzoRepository indirizzoRepository;
	
	public void saveIndirizzo(Indirizzo indirizzo) {
		indirizzoRepository.save(indirizzo);
	}
	
	public void deleteIndirizzo(Long id) {
		indirizzoRepository.deleteById(id);
	}
	public List<Indirizzo> findAllIndirizzo(Integer page, Integer size){
		 Pageable paging = PageRequest.of(page, size);
	        Page<Indirizzo> pagedResult = indirizzoRepository.findAll(paging);
	        if (pagedResult.hasContent()) {
	            return pagedResult.getContent();
	        } else {
	            return new ArrayList<Indirizzo>();
	        }
	}
	
	public void updateIndirizzo(Long id, Indirizzo indirizzo) {
		Indirizzo indirizzo1 = indirizzoRepository.getById(id);
		indirizzo1.setCap(indirizzo.getCap());
		indirizzo1.setCivico(indirizzo.getCivico());
		indirizzo1.setComune(indirizzo.getComune());
		indirizzo1.setLocalita(indirizzo.getLocalita());
		indirizzo1.setVia(indirizzo.getVia());
		indirizzoRepository.save(indirizzo1);
		
	
	}
	public Indirizzo findByVia(String via) {
		return indirizzoRepository.findByVia(via);
	}
}
