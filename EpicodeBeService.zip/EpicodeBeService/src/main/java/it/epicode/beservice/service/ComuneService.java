package it.epicode.beservice.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.beservice.model.Comune;
import it.epicode.beservice.repository.ComuneRepository;
import it.epicode.beservice.repository.ProvinciaRepository;

@Service
public class ComuneService {
	@Autowired
	ComuneRepository comuneRepository;
	@Autowired
	ProvinciaRepository provinciaRepository;

	public void saveComune() {
		final int INDICE_PROVINCIA = 3;
		final int INDICE_NOME = 2;
		final String FILE = "C:\\Users\\Utente\\Desktop\\FileProgettoFinale\\comuni-italiani.csv";
		try {
			BufferedReader br = new BufferedReader(new FileReader(FILE));
			String line = null;// variabile per leggere le righe del file
			int count = 0;
			while ((line = br.readLine()) != null) {
				count++;
				if (count != 1) {
					String[] parti = line.split(";");
					String nome = parti[INDICE_NOME];
					Comune comune = new Comune(nome, provinciaRepository.findByNomeContains(parti[INDICE_PROVINCIA]));
					comuneRepository.save(comune);
				}

			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update(Long id, Comune c) {
		Comune result = comuneRepository.getById(id);
		result.setNome(c.getNome());
		result.setProvincia(c.getProvincia());
		comuneRepository.save(result);
	}


	public void saveNewComune(Comune comune) {
		comuneRepository.save(comune);
	}

	public void deleteComune(Long id) {
		comuneRepository.deleteById(id);
	}
	public Page<Comune> findAll(Integer page, Integer size){
		Pageable pageable = PageRequest.of(page, size);
		return comuneRepository.findAll(pageable);
	}
}
