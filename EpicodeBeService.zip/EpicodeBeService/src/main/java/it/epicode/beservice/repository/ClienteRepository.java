package it.epicode.beservice.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import it.epicode.beservice.model.Cliente;

public interface ClienteRepository  extends JpaRepository<Cliente, Long>{

	
	Page<Cliente> findAll(Pageable pageable);
	
	Page<Cliente> findByFatturatoAnnuale(Long fatturatoAnnuale, Pageable pageable);
	
	Page<Cliente> findByDataInserimento(LocalDate dataInserimento, Pageable pageable);
	
	Page<Cliente> findByDataUltimoContatto(LocalDate dataUltimoContatto, Pageable pageable);
	
	Page<Cliente> findByRagioneSocialeContains(String string, Pageable pageable);

	Cliente findByRagioneSociale(String ragioneSociale);
}
