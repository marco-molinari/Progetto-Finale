package it.epicode.beservice.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class Fattura {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private Cliente cliente;
	private LocalDate data;
	private Integer numero;
	private Integer anno;
	private Long importo;
	@OneToOne
	private StatoFattura stato;
	
	public Fattura() {
		
	}

	public Fattura(Cliente cliente, LocalDate data, int numero, Integer anno, Long importo, StatoFattura stato) {
		this.cliente = cliente;
		this.data = data;
		this.numero = numero;
		this.anno = anno;
		this.importo = importo;
		this.stato = stato;
	}
	
}
