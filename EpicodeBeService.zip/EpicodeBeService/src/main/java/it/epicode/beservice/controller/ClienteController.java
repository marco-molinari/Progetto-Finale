package it.epicode.beservice.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.model.TipoCliente;
import it.epicode.beservice.service.ClienteService;

@RestController
@RequestMapping("/clientcontroller")
public class ClienteController {

	@Autowired
	ClienteService clienteService;

	@GetMapping("/orderbynome")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortNome(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "ragioneSociale") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);

	}
	//Thymeleaf
	@GetMapping("/orderbynometemplate")
	public ModelAndView getAllClientePageSizeSortNome(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "ragioneSociale") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ModelAndView("clienti").addObject("clienti",list);
				}
	@GetMapping("/orderbyfatturatoannuale")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortFatturato(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "fatturatoAnnuale") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);

	}
	//Thymeleaf
	@GetMapping("/orderbyfatturatoannualetemplate")
	public ModelAndView myGetAllClientePageSizeSortFatturatoTemplate(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "fatturatoAnnuale") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ModelAndView("clienti").addObject("clienti",list);
	}
	@GetMapping("/orderbydatainserimento")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortDataInserimento(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "dataInserimento") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);

	}
	//Thymeleaf
	@GetMapping("/orderbydatainserimentotemplate")
	public ModelAndView myGetAllClientePageSizeSortDataInserimentoTemplate(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "dataInserimento") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ModelAndView("clienti").addObject("clienti",list);
	}
	@GetMapping("/orderbydatacontatto")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortDataContatto(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "dataUltimoContatto") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);

	}
	@GetMapping("/orderbydatacontattotemplate")
	public ModelAndView myGetAllClientePageSizeSortDataContattoTemplate(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "dataUltimoContatto") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ModelAndView("clienti").addObject("clienti",list);
	}
	@GetMapping("/orderbyprovincia")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortByProvincia(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "indirizzoSedeLegale.comune.provincia") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);

	}
	@GetMapping("/orderbyprovinciatemplate")
	public ModelAndView myGetAllClientePageSizeSortByProvinciaTemplate(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "indirizzoSedeLegale.comune.provincia") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ModelAndView("clienti").addObject("clienti",list);

	}
	
	@GetMapping("/orderbynomecontatto")
	public ResponseEntity<List<Cliente>> myGetAllClientePageSizeSortNomeContatto(@RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size, @RequestParam(defaultValue = "nomeContatto") String sort) {
		List<Cliente> list = clienteService.myFindAllClientiPageSizeSort(page, size, sort);
		return new ResponseEntity<List<Cliente>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@PostMapping("/savenewclient")
	public ResponseEntity<String> saveNewClient(@RequestBody Cliente c){
		clienteService.saveCliente(c);
		return new ResponseEntity<String>("Cliente salvato correttamente", new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/savenewclientget")
	public ModelAndView saveNewClient(@RequestParam String ragioneSociale, String partitaIva, TipoCliente tipoCliente,
			String email, String pec, String telefono, String nomeContatto, String cognomeContatto, String telefonoContatto,
			String emailContatto, String indirizzoSedeOperativa,String indirizzoSedeLegale, @DateTimeFormat(iso = ISO.DATE)LocalDate dataInserimento,
			@DateTimeFormat(iso = ISO.DATE) LocalDate dataUltimoContatto,Long fatturatoAnnuale){
		clienteService.saveCliente2(ragioneSociale, partitaIva,tipoCliente, email,pec,telefono, nomeContatto,cognomeContatto,
				telefonoContatto,emailContatto, indirizzoSedeOperativa,indirizzoSedeLegale,dataInserimento,dataUltimoContatto,fatturatoAnnuale);
		return new ModelAndView("responcesignup").addObject("stato","Cliente Salvato Correttamente");
	}
	
	@GetMapping("/deleteclient")
	public ResponseEntity<String> deleteClient(@RequestParam Long id){
		clienteService.deleteCliente(id);
		return new ResponseEntity<String>("Cliente cancellato", new HttpHeaders(), HttpStatus.OK);
	}
	
	@PostMapping(value = "/updateclient/{id}")
	public void modificaCliente(@PathVariable Long id,@RequestBody Cliente client) {
		clienteService.modificaCliente(id, client);
	}
		
	@GetMapping("/findbyfatturato")
	public Page<Cliente> findByFatturato(@RequestParam Long fatturato, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		return clienteService.findByFatturato(fatturato, paging);
	}
	//Thymeleaf
	@GetMapping("/findbyfatturatotemplate")
	public ModelAndView findByFatturatoTemplate(@RequestParam Long fatturato, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		Page<Cliente> list=clienteService.findByFatturato(fatturato,paging);
		return new ModelAndView("clienti").addObject("clienti", list.getContent());
	}
	@GetMapping("/findbydatainserimento")
	public Page<Cliente> findByDataInserimento(@RequestParam @DateTimeFormat(iso=ISO.DATE) LocalDate dataInserimento, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		return clienteService.findByDataInserimento(dataInserimento,paging);
	}
	//Thymleaf
	@GetMapping("/findbydatainserimentotemplate")
	public ModelAndView findByDataInserimentoTemplate(@RequestParam @DateTimeFormat(iso=ISO.DATE) LocalDate dataInserimento, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		Page<Cliente> list=clienteService.findByDataInserimento(dataInserimento,paging);
		return new ModelAndView("clienti").addObject("clienti", list.getContent());
	}
	@GetMapping("/findbydatacontatto")
	public Page <Cliente> findByDataContatto(@RequestParam @DateTimeFormat(iso=ISO.DATE) LocalDate dataContatto, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		return clienteService.findByDataContatto(dataContatto,paging);
	}
	//Thymeleaf
	@GetMapping("/findbydatacontattotemplate")
	public ModelAndView findByDataContattoTemplate(@RequestParam @DateTimeFormat(iso=ISO.DATE) LocalDate dataContatto, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		Page<Cliente> list=clienteService.findByDataContatto(dataContatto,paging);
		return new ModelAndView("clienti").addObject("clienti", list.getContent());
	}
	@GetMapping("/findbyragionesociale")
	public Page<Cliente> findByPartediNome(@RequestParam String ragioneSociale, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		return clienteService.findByPartediNome(ragioneSociale,paging);
	}
	//Thymeleaf
	@GetMapping("/findbyragionesocialetemplate")
	public ModelAndView findByPartediNomeTemplate(@RequestParam String ragioneSociale, @RequestParam(defaultValue = "0") Integer page,
			@RequestParam(defaultValue = "2") Integer size){
		Pageable paging = PageRequest.of(page, size);
		Page<Cliente>list= clienteService.findByPartediNome(ragioneSociale,paging);
		return new ModelAndView("clienti").addObject("clienti", list.getContent());
	}
	@GetMapping(value="/detail/{id}")
	 public ModelAndView getCliente(@PathVariable Long id) {
		 return new ModelAndView("dettaglioclienti").addObject("cliente", clienteService.getById(id));
	 }
	@GetMapping(value = "/deleteclientetemplate/{id}")
	public ModelAndView deleteClientTemplate(@PathVariable Long id) {
		clienteService.deleteCliente(id);
		return new ModelAndView("responseclient","stato","ELIMINATO!");
	}
	@GetMapping(value = "/modificaclientetemplate/{id}")
	public ModelAndView updateClienteTemplate(@PathVariable Long id, @RequestParam String ragioneSociale, String partitaIva, TipoCliente tipoCliente,
			String email, String pec, String telefono, String nomeContatto, String cognomeContatto, String telefonoContatto,
			String emailContatto, String indirizzoSedeOperativa,String indirizzoSedeLegale, @DateTimeFormat(iso = ISO.DATE)LocalDate dataInserimento,
			@DateTimeFormat(iso = ISO.DATE) LocalDate dataUltimoContatto,Long fatturatoAnnuale) {
		clienteService.updateCliente2( id,ragioneSociale, partitaIva,tipoCliente, email,pec,telefono, nomeContatto,cognomeContatto,
				telefonoContatto,emailContatto, indirizzoSedeOperativa,indirizzoSedeLegale,dataInserimento,dataUltimoContatto,fatturatoAnnuale);
		return new ModelAndView("responseclient","stato","MODIFICATO!");
	}
}
