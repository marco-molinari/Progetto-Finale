package it.epicode.beservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.epicode.beservice.model.Provincia;
import it.epicode.beservice.service.ProvinciaService;

@RestController
@RequestMapping("/provinciacontroller")
public class ProvinciaController {

	@Autowired
	ProvinciaService provinciaService;
	@PostMapping("/save")
	public String saveProvincia(@RequestBody Provincia provincia) {
		provinciaService.saveProvincia(provincia);
		return "Provicnia inserita correttamente";
	}
	@PostMapping("/update/{id}")
	public String updateProvincia(@PathVariable Long id, @RequestBody Provincia provincia) {
		provinciaService.updateProvincia(id, provincia);
		return "Provicnia inserita correttamente";
	}
	@GetMapping("/delete")
	public String deleteProvincia(@RequestParam Long id) {
		provinciaService.deleteProvincia(id);
		return "Provicnia inserita correttamente";
	}
}
