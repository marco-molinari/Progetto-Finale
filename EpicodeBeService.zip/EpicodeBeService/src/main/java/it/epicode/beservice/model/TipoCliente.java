package it.epicode.beservice.model;

import javax.persistence.Entity;


public enum TipoCliente {
	SRL,SPA,SAS,PA;
}
