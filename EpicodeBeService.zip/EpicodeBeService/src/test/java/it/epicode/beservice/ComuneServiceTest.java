package it.epicode.beservice;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

import it.epicode.beservice.service.ComuneService;
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class ComuneServiceTest {
	@Autowired
	ComuneService comuneService;
	@Test
	void findAllComuneTest() {
		assertTrue(comuneService.findAll(0, 2).hasContent());
	}

}
